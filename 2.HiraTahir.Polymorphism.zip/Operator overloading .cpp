
#include <iostream>
using namespace std;

class space {
    int x;
    int y;
    int z;
public:
    void getdata(int a, int b, int c);
    void display();
    void operator-();
    friend ostream& operator<<(ostream& os, const space& s);
};

void space::getdata(int a, int b, int c) {
    x = a;
    y = b;
    z = c;
}

void space::display() {
    cout << x << " ";
    cout << y << " ";
    cout << z << " \n";
}

void space::operator-() {
    x = -x;
    y = -y;
    z = -z;
}

ostream& operator<<(ostream& os, const space& s) {
    os << s.x << " " << s.y << " " << s.z;
    return os;
}

int main() {
    space S;
    S.getdata(10, -20, 30);
    cout << S << endl; 
    S.display();
    -S;
    cout << "S=";
    S.display();

    return 0;
}
