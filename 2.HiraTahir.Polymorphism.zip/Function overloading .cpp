
#include <iostream>
using namespace std;
int volume (int s)
{ return (s*s*s);
}
double volume (double r,int h)
{ return (3.14*r*r*h);}
long volume (long l,int b,int h)
{ return (l*b*h);
}
int main ()
{ cout <<volume (10);
cout <<volume (2.5,8);
cout<<volume (100L,75,15);
}