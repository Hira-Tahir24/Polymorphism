

#include <iostream>
using namespace std;

class Base {
public:
    virtual void display() {
        cout << "Display base" << endl;
    }
};

class Derived : public Base {
public:
    void display() {
        cout << "Display Derived" << endl;
    }
};

int main() {
    Base B;
    Derived D;
    Base* bptr;

    bptr = &B;
    bptr->display();

    bptr = &D; // Corrected line to assign the address of Derived object D to the pointer bptr
    bptr->display();

    return 0;
}
