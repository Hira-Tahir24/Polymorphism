
# include <iostream>
using namespace std;




class Rectangle {
private:
    int width, height;
public:
    Rectangle(int w = 0, int h = 0) {
    width=w;
    height=h;}

    // Operator overloading for area calculation
    int operator*(const Rectangle& other) {
        return width * other.height;
    }

    void display() {
        cout << "Width: " << width << endl;
        cout <<"Height: " << height << endl;
    }
};

int main() {
    Rectangle r1(4, 5);
    Rectangle r2(2, 3);

    int area = r1 * r2; // Compile-time polymorphism
    std::cout << "Area: " << area << std::endl; // Output: Area: 12

    return 0;
}
