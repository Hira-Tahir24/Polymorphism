
#include <iostream>
using namespace std;
class Shape {
public:
    virtual void draw()  
    { cout << "Draw shape"<<endl;}
};

class Circle : virtual public Shape {
public:
    void draw() {
        std::cout << "Drawing a circle." << std::endl;
    }
};

class Rectangle : virtual public Shape {
public:
    void draw() {
        std::cout << "Drawing a rectangle." << std::endl;
    }
};

int main() {
    Shape* shape1 = new Circle();
    Shape* shape2 = new Rectangle();

    shape1->draw(); // Output: Drawing a circle.
    shape2->draw(); // Output: Drawing a rectangle.

    delete shape1;
    delete shape2;

    return 0;
}
