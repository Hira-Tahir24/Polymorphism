
# include <iostream>
using namespace std;


int add(int a, int b) {
    return a + b;
}

// Function to add three integers
int add(int a, int b, int c) {
    return a + b + c;
}

int main() {
    int sum1 = add(5, 10); // Calls the first add function
    int sum2 = add(5, 10, 15); // Calls the second add function

    std::cout << "Sum1: " << sum1 << std::endl;
    std::cout << "Sum2: " << sum2 << std::endl;

    return 0;
}
